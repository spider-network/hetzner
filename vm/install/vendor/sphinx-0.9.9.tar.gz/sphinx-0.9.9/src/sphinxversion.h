#define SPH_SVN_TAG "rel099"
#define SPH_SVN_REV 2117
#define SPH_SVN_REVSTR "2117"
#define SPH_SVN_TAGREV "rel099-r2117"
