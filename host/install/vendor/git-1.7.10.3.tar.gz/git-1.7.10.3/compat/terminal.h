#ifndef COMPAT_TERMINAL_H
#define COMPAT_TERMINAL_H

char *git_terminal_prompt(const char *prompt, int echo);

#endif /* COMPAT_TERMINAL_H */
